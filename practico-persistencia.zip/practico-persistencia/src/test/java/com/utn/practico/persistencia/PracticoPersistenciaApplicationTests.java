package com.utn.practico.persistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticoPersistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.utn.practico.persistencia.repositorio;

import com.utn.practico.persistencia.Entidades.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository extends JpaRepository <Pedido, Long> {
}

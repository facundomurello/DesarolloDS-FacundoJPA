package com.utn.practico.persistencia.enumeraciones;

public enum Estado {
    iniciado,
    entregado,
    preparacion

}

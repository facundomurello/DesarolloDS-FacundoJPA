package com.utn.practico.persistencia;

import com.utn.practico.persistencia.Entidades.*;
import com.utn.practico.persistencia.repositorio.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class PracticoPersistenciaApplication {

	@Autowired
	ClienteRepository clienteRepository;
	@Autowired
	DomicilioRepository domicilioRepository;
	@Autowired
	FacturaRepository facturaRepository;
	@Autowired
	DetallePedidoRepository detallePedido;
	@Autowired
	PedidoRepository pedidoRepository;
	@Autowired
	ProductoRepository productoRepository;
	@Autowired
	RubroRepository rubroRepository;


	public static void main(String[] args) {
		SpringApplication.run(PracticoPersistenciaApplication.class, args);
		System.out.println("Estoy funcionando");
	}

	@Bean
	CommandLineRunner init(ClienteRepository clienteRepository) {
		return args -> {
			System.out.println("-------funciono-------");



			// creacion de rubros
			Rubro rubro1 = Rubro.builder()
					.denominacion("ferreteria")
					.build();

			Rubro rubro2 = Rubro.builder()
					.denominacion("carpinteria")
					.build();

			// crear productos
			//Observacion: para que se mapean todos los productos a la BBDD, le tengo que agregar rubro

			Producto producto1 = Producto.builder()
					.tipo("manufacturado")
					.tiempoEstimadoCocina(253)
					.denominacion("hola")
					.precioCompra(2582)
					.precioCompra(2599)
					.stockActual(2)
					.stockMinimo(1)
					.unidadMedida("metros")
					.receta("intermedia")
					.build();

			Producto producto2 = Producto.builder()
					.tipo("manufacturado")
					.tiempoEstimadoCocina(2)
					.denominacion("ferreteria")
					.precioCompra(899)
					.precioCompra(25)
					.stockActual(8)
					.stockMinimo(2)
					.unidadMedida("metros")
					.receta("dificil")
					.build();

			Producto producto3 = Producto.builder()
					.tipo("insumo")
					.tiempoEstimadoCocina(3)
					.denominacion("automotriz")
					.precioCompra(2)
					.precioCompra(99)
					.stockActual(99)
					.stockMinimo(5)
					.unidadMedida("peso")
					.receta("facil")
					.build();

			Producto producto4 = Producto.builder()
					.tipo("manufacturado")
					.tiempoEstimadoCocina(39)
					.denominacion("Hogar")
					.precioCompra(2555)
					.precioCompra(2889)
					.stockActual(25)
					.stockMinimo(8)
					.unidadMedida("gramos")
					.receta("intermedia")
					.build();

			Producto producto5 = Producto.builder()
					.tipo("manufacturado")
					.tiempoEstimadoCocina(2553)
					.denominacion("ferreteria")
					.precioCompra(2882)
					.precioCompra(259559)
					.stockActual(2)
					.stockMinimo(1)
					.unidadMedida("metros")
					.receta("intermedia")
					.build();

			Producto producto6 = Producto.builder()
					.tipo("insumo")
					.tiempoEstimadoCocina(25555)
					.denominacion("Tecnologia")
					.precioCompra(2582)
					.precioCompra(2599)
					.stockActual(2)
					.stockMinimo(1)
					.unidadMedida("cantidad")
					.receta("intermedia")
					.build();

			//guardo los productos en el rubro
			rubro1.agregarProductoARubro(producto1);
			rubro1.agregarProductoARubro(producto2);
			rubro1.agregarProductoARubro(producto3);
			rubro2.agregarProductoARubro(producto4);
			rubro2.agregarProductoARubro(producto5);
			rubro2.agregarProductoARubro(producto6);

			//guardo el rubro
			rubroRepository.save(rubro1);
			rubroRepository.save(rubro2);

			//crear instancias de clientes
			Cliente cliente1 = Cliente.builder()
					.nombre("Facundo")
					.apellido("Murello")
					.telefono(2613)
					.email("murello86@gmail.com")
					.build();



			//crear instancias de domicilio
			Domicilio domicilio1 = Domicilio.builder()
					.calle("calle 1")
					.numero(123)
					.build();

			Domicilio domicilio2 = Domicilio.builder()
					.calle("calle san martin ")
					.numero(552)
					.build();


			//agregar domicilios a los clientes
			cliente1.agregarDomicilio(domicilio1);
			cliente1.agregarDomicilio(domicilio2);

			//CREAR INSTANCIAS DE DETALLE PEDIDO
			//detalles pedidos asociados al pedido 1
			DetallePedido detallePedido11 = DetallePedido.builder()
					.cantidad(8)
					.subtotal(550)
					.build();
			DetallePedido detallePedido12 = DetallePedido.builder()
					.cantidad(5)
					.subtotal(1500)
					.build();
			DetallePedido detallePedido13 = DetallePedido.builder()
					.cantidad(3)
					.subtotal(38)
					.build();

			//detalles pedidos asociados al pedido 2
			DetallePedido detallePedido21 = DetallePedido.builder()
					.cantidad(25)
					.subtotal(800)
					.build();
			DetallePedido detallePedido22 = DetallePedido.builder()
					.cantidad(55)
					.subtotal(15000)
					.build();
			DetallePedido detallePedido23 = DetallePedido.builder()
					.cantidad(33)
					.subtotal(3888)
					.build();


			//CREAR INSTANCIAS DE PEDIDOS
			Pedido pedido1 = Pedido.builder()
					.estado("preparacion")
					.fecha(91218)
					.tipoEnvio("delivery")
					.total(15200)
					.build();

			Pedido pedido2 = Pedido.builder()
					.estado("entregado")
					.fecha(1111)
					.tipoEnvio("retira")
					.total(3000)
					.build();

			Pedido pedido3 = Pedido.builder()
					.estado("En preparacion")
					.fecha(9122021)
					.tipoEnvio("retira")
					.total(5000)
					.build();

			//CREAR INSTANCIAS DE FACTURA
			Factura factura1 = Factura.builder()
					.numero(1)
					.fecha(91218)
					.descuento(0.30)
					.formaPago("efectivo")
					.total(4000)
					.build();

			Factura factura2 = Factura.builder()
					.numero(25)
					.fecha(912122)
					.descuento(0.25)
					.formaPago("mercado pago")
					.total(3526)
					.build();

			Factura factura3 = Factura.builder()
					.numero(85)
					.fecha(912122)
					.descuento(0.10)
					.formaPago("mercado pago")
					.total(3526)
					.build();



			//AGREGAR DETALLES AL PEDIDO
			//metodos para agregar los detalles al pedido 1
			pedido1.agregarDetallePedido(detallePedido11);
			pedido1.agregarDetallePedido(detallePedido12);
			pedido1.agregarDetallePedido(detallePedido13);

			//metodos para agregar los detalles al pedido 2
			pedido2.agregarDetallePedido(detallePedido21);
			pedido2.agregarDetallePedido(detallePedido22);
			pedido2.agregarDetallePedido(detallePedido23);

			//AGREGAR PEDIDOS AL CLIENTE
			cliente1.agregarPedido(pedido1);
			cliente1.agregarPedido(pedido2);
			cliente1.agregarPedido(pedido3);

			// DETALLE PEDIDO CON EL PRODUCTO
			detallePedido11.setProducto(producto1);
			detallePedido12.setProducto(producto2);
			detallePedido13.setProducto(producto3);
			detallePedido21.setProducto(producto4);
			detallePedido22.setProducto(producto5);
			detallePedido23.setProducto(producto6);

			//FACTURA CON PEDIDO
			pedido1.setFactura(factura1);
			pedido2.setFactura(factura2);
			pedido3.setFactura(factura3);

			clienteRepository.save(cliente1);


			//recuperar Cliente desde la base de Datos
			Cliente clienteRecuperado = clienteRepository.findById(cliente1.getId()).orElse(null);
			if (clienteRecuperado != null){
				System.out.println("Nombre: " + clienteRecuperado.getNombre());
				System.out.println("Apellido: " + clienteRecuperado.getApellido());
				System.out.println("Mail: " + clienteRecuperado.getEmail());
				System.out.println("Telefono: " + clienteRecuperado.getTelefono());
				System.out.println("----------------------------------------");
				clienteRecuperado.mostrarDomicilios();
				clienteRecuperado.mostrarPedidos();

			}
		};
	}





}





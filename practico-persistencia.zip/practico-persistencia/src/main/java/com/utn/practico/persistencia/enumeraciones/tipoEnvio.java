package com.utn.practico.persistencia.enumeraciones;

public enum tipoEnvio {
    delivery,
    takeAway
}

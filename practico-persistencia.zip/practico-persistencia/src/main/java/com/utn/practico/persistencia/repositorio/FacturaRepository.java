package com.utn.practico.persistencia.repositorio;

import com.utn.practico.persistencia.Entidades.Factura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacturaRepository extends JpaRepository <Factura, Long> {

}

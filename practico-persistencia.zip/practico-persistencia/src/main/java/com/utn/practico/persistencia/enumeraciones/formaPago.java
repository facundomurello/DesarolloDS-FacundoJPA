package com.utn.practico.persistencia.enumeraciones;

public enum formaPago {
    efectivo,
    mercadoPago
}

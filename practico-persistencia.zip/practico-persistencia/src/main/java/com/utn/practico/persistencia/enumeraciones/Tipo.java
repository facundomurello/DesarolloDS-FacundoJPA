package com.utn.practico.persistencia.enumeraciones;

public enum Tipo {
    manufacturado,
    insumo
}
